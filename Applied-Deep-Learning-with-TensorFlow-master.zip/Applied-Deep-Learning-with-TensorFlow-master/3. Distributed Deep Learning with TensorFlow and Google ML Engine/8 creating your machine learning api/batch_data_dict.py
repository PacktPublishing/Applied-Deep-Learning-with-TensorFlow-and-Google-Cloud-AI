
requestDict = {
    'instances': 
          [
                {
                      "Lat": 37.4434774, "Long": -122.1652269, 
                      "Altitude": 21.0, "Date_": "7/4/17",
                       "Time_": "23:37:25", "dt_": "7/4/17 23:37" 
                       #driving meet conjestion
                },
                {
                      "Lat": 37.429302, "Long": -122.16145, 
                      "Altitude": 20.0, "Date_": "7/4/17",
                       "Time_": "09:37:25", "dt_": "7/4/17 09:37" 
                       #driving meet conjestion
                }
          ]     
}